
public class EmpregadoComissionadoComBase extends EmpregadoComissionado
{
   private double salarioBase; 

   public EmpregadoComissionadoComBase( String primeiro, String ultimo,
      String cpf, double vendas, double taxa, double salario )
   {
      super( primeiro, ultimo, cpf, vendas, taxa );
      setSalarioBase( salario ); 
   } 

   public void setSalarioBase( double salario )
   {
      salarioBase = ( salario < 0.0 ) ? 0.0 : salario;
   } 

   public double getSalarioBase()
   {
      return salarioBase;
   } 

   @Override 
   public double ganhos()
   {
      return getSalarioBase() + super.ganhos();
   } 

   @Override 
   public String toString()
   {
      return String.format( "%s %s\n%s: %.2f", "sal�rio-base",
         super.toString(), "sal�rio base", getSalarioBase() );
   } 
}






public class BoletimTeste1
{
   
   public static void main( String[] args )
   {
      
      Boletim1 boletim = new Boletim1();

      boletim.displayMessage();
   } 
} 



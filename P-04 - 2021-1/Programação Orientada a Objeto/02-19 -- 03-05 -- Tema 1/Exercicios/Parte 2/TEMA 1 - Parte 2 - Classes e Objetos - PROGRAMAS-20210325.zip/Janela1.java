
import javax.swing.JOptionPane; 

public class Janela1
{
   public static void main( String[] args )
   {
      
      JOptionPane.showMessageDialog( null, "Bem-vindo ao Java" );
   } 
} 





public class Boletim1
{
   
   public void displayMessage()
   {
      	System.out.println( "Bem-vindo ao seu boletim!" );
   } 
   
} 



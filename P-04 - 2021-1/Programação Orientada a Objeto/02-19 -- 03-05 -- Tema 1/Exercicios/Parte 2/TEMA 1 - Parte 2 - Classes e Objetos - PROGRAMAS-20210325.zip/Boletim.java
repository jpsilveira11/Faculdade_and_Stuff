

public class Boletim
{
   
   public void displayMessage()
   {
      	System.out.println( "Bem-vindo ao seu boletim!" );
   } 
   public static void main(String[] args){
	Boletim boletim = new Boletim();
	boletim.displayMessage();
   }
} 



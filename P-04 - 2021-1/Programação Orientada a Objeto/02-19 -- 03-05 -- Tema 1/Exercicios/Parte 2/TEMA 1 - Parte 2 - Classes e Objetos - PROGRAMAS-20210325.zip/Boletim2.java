

public class Boletim2
{
   
   public void displayMessage( String nomeDoCurso )
   {
      System.out.printf( "Bem-vindo ao seu boletim do curso de %s!\n",
         nomeDoCurso );
   } 
} 



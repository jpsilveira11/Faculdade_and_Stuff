
public class BemVindo
{
   // m�todo main inicia a execu��o da aplica��o Java
   public static void main( String[] args )
   {
      System.out.println( "Bem-vindo ao Java!" );
   } // fim do m�todo main
} // fim da classe BemVindo



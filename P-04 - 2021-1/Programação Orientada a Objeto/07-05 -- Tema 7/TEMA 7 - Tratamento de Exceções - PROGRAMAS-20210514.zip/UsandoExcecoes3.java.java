
public class UsandoExcecoes3
{
   public static void main( String[] args )
   {
      try
      {
         metodo1(); 
      } 
      catch ( Exception e ) 
      {
         System.err.printf( "%s\n\n", e.getMessage() );
         e.printStackTrace(); 

         StackTraceElement[] pilhaDeElementos = e.getStackTrace();

         System.out.println( "\nRastreio da pilha a partir de getStackTrace:" );
         System.out.println( "Classe\t\tArquivo\t\t\tLinha\tM�todo" );

         for ( StackTraceElement elemento : pilhaDeElementos )
         {
            System.out.printf( "%s\t", elemento.getClassName() );
            System.out.printf( "%s\t", elemento.getFileName() );
            System.out.printf( "%s\t", elemento.getLineNumber() );
            System.out.printf( "%s\n", elemento.getMethodName() );
         } 
      } 
   } 

   public static void metodo1() throws Exception
   {
      metodo2();
   } 

   public static void metodo2() throws Exception
   {
      metodo3();
   } 

   public static void metodo3() throws Exception
   {
      throw new Exception( "Exce��o lan�ada no metodo3" );
   } 
} 


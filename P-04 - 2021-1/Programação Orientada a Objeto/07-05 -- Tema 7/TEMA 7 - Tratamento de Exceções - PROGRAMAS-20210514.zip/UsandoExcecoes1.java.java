
public class UsandoExcecoes1
{
   public static void main( String[] args )
   {
      try
      {
         disparaExcecao(); 
      } 
      catch ( Exception exception ) 
      {
         System.err.println( "Exce��o capturada no m�todo main" );
      } 

      naoDisparaExcecao();
   } 

  
   public static void disparaExcecao() throws Exception
   {
      try 
      {
         System.out.println( "M�todo disparaExcecao" );
         throw new Exception(); //dispara uma exce��o
      } 
      catch ( Exception excecao ) 
      {
         System.err.println(
            "Exce��o tratada no m�todo disparaExcecao" );
         throw excecao;
      }
      finally // executa independentemente do que ocorre no bloco try...catch
      {
         System.err.println( "Finally executado em disparaExcecao" );
      } 
   } 

   // demonstra finally quando n�o ocorre nenhuma exce��o
   public static void naoDisparaExcecao()
   {
      try 
      {
         System.out.println( "M�todo naoDisparaExcecao" );
      }
      catch ( Exception excecao ) // does not execute
      {
         System.err.println( excecao );
      } 
      finally 
      {
         System.err.println(
            "Finally executado em naoDisparaExcecao" );
      } 

      System.out.println( "Fim do m�todo naoDisparaExcecao" );
   } 
} 



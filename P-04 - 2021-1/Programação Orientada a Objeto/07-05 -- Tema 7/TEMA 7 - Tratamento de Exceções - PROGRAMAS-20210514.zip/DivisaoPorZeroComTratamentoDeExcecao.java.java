
import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisaoPorZeroComTratamentoDeExcecao{

   public static int quociente( int numerador, int denominador )
      throws ArithmeticException
   {
      return numerador / denominador; // poss�vel divis�o por zero
   } 

   public static void main( String[] args )
   {
      Scanner entrada = new Scanner( System.in ); 
      boolean continueLoop = true; // determina se mais entradas s�o necess�rias

      do
      {
         try // l� dois inteiros e calcula o quociente
         {
            System.out.print( "Digite um inteiro para o numerador: " );
            int numerador = entrada.nextInt();
            System.out.print( "Digite um inteiro para o denominador: " );
            int denominador = entrada.nextInt();

            int resultado = quociente( numerador, denominador );
            System.out.printf( "\nResultado: %d / %d = %d\n", numerador,
               denominador, resultado );
            continueLoop = false; // encerra o loop
         } 
         catch ( InputMismatchException inputMismatchException )
         {
            System.err.printf( "\nExce��o: %s\n",
               inputMismatchException );
            entrada.nextLine(); 
            System.out.println(
               "Voc� deve digitar inteiros. Tente novamente.\n" );
         } 
         catch ( ArithmeticException arithmeticException )
         {
            System.err.printf( "\nExce��o: %s\n", arithmeticException );
            System.out.println(
               "Zero n�o pode ser denominador. Tente novamente.\n" );
         } 
      } while ( continueLoop ); 
   } 
} 



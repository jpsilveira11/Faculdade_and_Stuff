
import java.util.Scanner;

public class DivisaoPorZeroSemTratarExcecao
{
   public static int quociente( int numerator, int denominator )
   {
      return numerator / denominator; // poss�vel divis�o por zero
   } 

   public static void main( String[] args )
   {
      Scanner entrada = new Scanner( System.in ); 

      System.out.print( "Digite um inteiro para o numerador: " );
      int numerador = entrada.nextInt();
      System.out.print( "Digite um inteiro para o denominador: " );
      int denominador = entrada.nextInt();

      int resultado = quociente( numerador, denominador );
      System.out.printf(
         "\nResultado: %d / %d = %d\n", numerador, denominador, resultado );
   } 
} 



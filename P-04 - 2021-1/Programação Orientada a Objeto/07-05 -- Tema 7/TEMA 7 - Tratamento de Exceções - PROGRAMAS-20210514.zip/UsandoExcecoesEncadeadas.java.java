
public class UsandoExcecoesEncadeadas
{
   public static void main( String[] args )
   {
      try
      {
         metodo1(); 
      } 
      catch ( Exception e ) 
      {
         e.printStackTrace();
      } 
   } 

   public static void metodo1() throws Exception
   {
      try
      {
         metodo2(); 
      } 
      catch ( Exception e ) 
      {
         throw new Exception( "Exce��o lan�ada no metodo1", e );
      } 
   } 

   public static void metodo2() throws Exception
   {
      try
      {
         metodo3(); 
      } 
      catch ( Exception exc ) 
      {
         throw new Exception( "Exce��o lan�ada no metodo2", exc );
      } 
   } 

   public static void metodo3() throws Exception
   {
      throw new Exception( "Exce��o lan�ada no metodo3" );
   } 
} 



public class UsandoExcecoes2
{
   public static void main( String[] args )
   {
      try 
      {
         disparaExcecao();
      } 
      catch ( Exception e ) 
      {
         System.err.println( "Exce��o tratada no m�todo main" );
      } 
   } 

   public static void disparaExcecao() throws Exception
   {
      try 
      {
         System.out.println( "M�todo disparaExcecao" );
         throw new Exception(); 
      } 
      catch ( RuntimeException runtimeException ) // catch em tipo incorreto
      {
         System.err.println(
            "Exce��o tratada no m�todo disparaExcecao" );
      } 
      finally 
      {
         System.err.println( "\nFinally � sempre executado" );
      } 
   } 
}



public class CrapsTeste
{
   public static void main( String[] args )
   {
      Craps game = new Craps();
      game.play(); 
   } 
} 


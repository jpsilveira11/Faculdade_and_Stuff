
public class EscopoTeste
{
   public static void main( String[] args )
   {
      Escopo testeDeEscopo = new Escopo();
      testeDeEscopo.inicio();
   } 
} 


